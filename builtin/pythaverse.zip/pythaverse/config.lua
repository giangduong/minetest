SSO ={
    url="https://id.leanbot.space/auth/realms/idp/protocol/openid-connect/token"
    ,client_id = "qa-lms.leanbot.space"
    ,client_secret = "0bum7DQnHfdvfr6XUMbiXcGaFABWAoAs"
   
    
}

PYTHAVERSE={
    url="https://qa-apis.leanbot.space/api/pythaverse"
    ,jsonRequest = '{"func":"06","body":{}}'
    
}

THAMSO={
     url= "https://qa-apis.leanbot.space/api/thamso/get?jsonRequest="   
    ,jsonRequest ="ew0KICAgICAgICAiZnVuYyI6ICIwNyIsDQogICAgICAgICJib2R5Ijogew0KICAgICAgICAgICAgICAia2V5IjoibGVhbmJvdF90b2tlbiINCiAgICAgICAgfQ0KICAgIH0=",
    
}

